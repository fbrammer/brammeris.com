#!/usr/bin/env bash
#
# aia-setup.sh — the guided installer for your AI assistant (Mac and Linux).
#
# Usage:
#   ./aia-setup.sh                 run the full setup
#   ./aia-setup.sh --check         doctor mode: check everything, change nothing
#   ./aia-setup.sh --base <path>   put the assistant folder somewhere else
#   ./aia-setup.sh --env <path>    read a setup file from somewhere else
#
# Exit codes: 0 success, 1 a stop-the-run failure, 2 a bad command line.
#
# Environment:
#   AIA_DRY_RUN=1   rehearsal mode, used by the test suite and by anyone who
#                   wants to see the steps without side effects on their system.
#                   It still creates the assistant folder, unpacks files, starts
#                   version history and merges settings — so the "check, then
#                   skip if already correct" logic is genuinely exercised and a
#                   second run reports everything as already done. It does NOT
#                   install Hermes, open a browser, start the local key page, or
#                   make any network call. Settings go to <BASE>/.hermes/ rather
#                   than your real config folder.
#   AIA_SOURCE      folder holding the shipped files (defaults to the zip or the
#                   aiaFFS folder beside this script).
#   AIA_CONFIG      full path to the real settings file.
#
# This script never prints, logs, or stores a credential. Keys you paste go
# straight from the local page into your settings folder and nowhere else.

set -uo pipefail

HOME="${HOME:-/tmp}"
PATH="${PATH:-/usr/bin:/bin:/usr/sbin:/sbin}"
export HOME PATH

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/checks.sh
. "${SCRIPT_DIR}/lib/checks.sh"

CHECK_MODE=0
DRY_RUN="${AIA_DRY_RUN:-0}"
ENV_FILE="./env.txt"
BASE=""
HERMES_BIN=""
# These are read by the functions in lib/checks.sh.
# shellcheck disable=SC2034
COMPLETED=()
WORKING_PROVIDERS=()
ENV_BASE=""
# shellcheck disable=SC2034
ENV_PROVIDERS=""
# shellcheck disable=SC2034
ENV_VERSION=""
# shellcheck disable=SC2034
RERUN_COMMAND="$0"

usage() {
  printf '%s\n' "Usage: $0 [--check] [--base <path>] [--env <path>]"
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --check) CHECK_MODE=1; shift ;;
    --base)  [ "$#" -ge 2 ] || { usage; exit 2; }; BASE="$2"; shift 2 ;;
    --env)   [ "$#" -ge 2 ] || { usage; exit 2; }; ENV_FILE="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) printf '%s\n' "I do not understand the option: $1"; usage; exit 2 ;;
  esac
done

say() { printf '%s\n' "$*"; }
step() { printf '\n== %s\n' "$*"; }

# ------------------------------------------------------- where things live --

resolve_source_dir() {
  if [ -n "${AIA_SOURCE:-}" ] && [ -d "$AIA_SOURCE" ]; then
    SOURCE_DIR="$AIA_SOURCE"
    return 0
  fi
  # The zip beside this script is the normal case. Extracting it needs a tool:
  # unzip if present, otherwise python3's zipfile module (shipped with Python on
  # nearly every Linux distro). If neither exists, say so honestly — this is a
  # missing tool, not a missing bundle, and the caller's "bundle is missing"
  # message would send the user off to re-download for no reason.
  if [ -f "${SCRIPT_DIR}/aiaFFS.zip" ]; then
    SOURCE_DIR="$(mktemp -d)"
    if command -v unzip >/dev/null 2>&1; then
      unzip -q -o "${SCRIPT_DIR}/aiaFFS.zip" -d "$SOURCE_DIR" || return 1
    elif command -v python3 >/dev/null 2>&1; then
      say "unzip is not installed; unpacking the bundle with python3 instead."
      python3 -m zipfile -e "${SCRIPT_DIR}/aiaFFS.zip" "$SOURCE_DIR" || return 1
    else
      fail "this computer has no way to unpack the file bundle. Install unzip and run this script again — on Ubuntu or Debian: sudo apt install unzip; on Fedora: sudo dnf install unzip. (Installing python3 works too.)"
    fi
    # Verify: the extraction must actually have produced files.
    [ -n "$(ls -A "$SOURCE_DIR" 2>/dev/null)" ] || return 1
    return 0
  fi
  if [ -d "${SCRIPT_DIR}/../aiaFFS" ]; then
    SOURCE_DIR="$(cd "${SCRIPT_DIR}/../aiaFFS" && pwd)"
    return 0
  fi
  return 1
}

# --------------------------------------------- the local key-entry page (10) --
# Binds 127.0.0.1 on a kernel-chosen port, serves one small form, takes one POST,
# checks each key against its provider live, and shuts down. The helper writes
# accepted keys straight into the settings folder itself, so no key is ever held
# in a shell variable, printed, or written to the log.

run_key_page_once() {
  local work url_file out_file pid waited=0 url=""
  command -v python3 >/dev/null 2>&1 || return 1
  work="$(mktemp -d)" || return 1
  url_file="${work}/url"
  out_file="${work}/out"
  python3 - "$HERMES_ENV_FILE" >"$out_file" 2>"$url_file" <<'PY' &
import http.server, json, os, socket, ssl, sys, threading, urllib.error, urllib.request
from urllib.parse import parse_qs

HERMES_ENV = sys.argv[1]
# Each probe must hit an endpoint that actually REQUIRES the key — both
# providers' /v1/models are public and answer 200 to any nonsense, which would
# make failure mode 12 useless.
PROBES = {
    "openrouter": ("https://openrouter.ai/api/v1/key", None, "OPENROUTER_API_KEY"),
    "nvidia": ("https://integrate.api.nvidia.com/v1/chat/completions",
               b'{"model":"meta/llama-3.1-8b-instruct",'
               b'"messages":[{"role":"user","content":"hi"}],"max_tokens":1}',
               "NVIDIA_API_KEY"),
}
FORM = """<!doctype html><meta charset=utf-8><title>Your backup keys</title>
<style>body{font:16px system-ui;margin:3rem auto;max-width:34rem}
input{width:100%%;padding:.5rem;font:inherit}label{display:block;margin:1.2rem 0 .3rem}
button{margin-top:1.5rem;padding:.6rem 1.2rem;font:inherit}.e{color:#a00}</style>
<h1>Your backup keys</h1>
<p>This page is running on your own computer. Nothing you type here leaves it —
it goes into your settings file and nowhere else. Leave a box empty to skip that
provider; you can add it later by asking your assistant.</p>
<p class=e>%s</p>
<form method=post>
<label>OpenRouter key (optional)</label><input name=openrouter type=password autocomplete=off>
<label>NVIDIA key (optional)</label><input name=nvidia type=password autocomplete=off>
<button type=submit>Save and finish</button></form>"""

result = {"accepted": [], "rejected": [], "submitted": False}
ctx = ssl.create_default_context()


def probe(provider, secret):
    url, payload, _ = PROBES[provider]
    headers = {"Authorization": "Bearer " + secret}
    if payload:
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=payload, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=20, context=ctx) as r:
            return r.status < 400
    except urllib.error.HTTPError as e:
        # 401/403 means the key is wrong. Anything else means the key got
        # through and the provider merely disliked the request itself.
        return e.code not in (401, 403)
    except Exception:
        return False


def store(secret_map):
    lines = []
    if os.path.exists(HERMES_ENV):
        with open(HERMES_ENV) as fh:
            lines = [ln for ln in fh.read().splitlines()
                     if ln.split("=", 1)[0] not in secret_map]
    lines += ["%s=%s" % (k, v) for k, v in secret_map.items()]
    os.makedirs(os.path.dirname(HERMES_ENV), exist_ok=True)
    fd = os.open(HERMES_ENV, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        fh.write("\n".join(lines) + "\n")
    # The mode above only applies when the file is created; an existing .env at
    # looser permissions has to be tightened explicitly.
    os.chmod(HERMES_ENV, 0o600)


class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _page(self, msg=""):
        body = (FORM % msg).encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._page()

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        form = parse_qs(self.rfile.read(n).decode())
        result["submitted"] = True
        good, bad = {}, []
        for provider, (_, _payload, var) in PROBES.items():
            secret = (form.get(provider, [""])[0] or "").strip()
            if not secret:
                continue
            if probe(provider, secret):
                good[var] = secret
                result["accepted"].append(provider)
            else:
                bad.append(provider)
        if bad and not good:
            # FAILMODE 12 retry: same page, plain words, no key echoed back.
            result["submitted"] = False
            result["rejected"] = bad
            self._page("That key did not work. Check it and try again, or leave "
                       "it empty to skip.")
            return
        result["rejected"] = bad
        if good:
            store(good)
        body = b"<!doctype html><meta charset=utf-8><p>Saved. You can close this tab."
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)
        threading.Thread(target=self.server.shutdown, daemon=True).start()


try:
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
except (OSError, socket.error):
    sys.exit(3)
port = srv.server_address[1]
sys.stderr.write("http://127.0.0.1:%d/\n" % port)
sys.stderr.flush()
t = threading.Thread(target=srv.serve_forever, daemon=True)
t.start()
t.join(timeout=int(os.environ.get("AIA_KEY_PAGE_TIMEOUT", "300")))
srv.shutdown()
print(json.dumps(result))
PY
  pid=$!
  # Wait for the listener to report the address it actually got, then open it.
  while [ "$waited" -lt 100 ]; do
    if [ -s "$url_file" ]; then
      url="$(head -n 1 "$url_file")"
      break
    fi
    if ! kill -0 "$pid" 2>/dev/null; then
      break
    fi
    sleep 0.1
    waited=$((waited + 1))
  done
  case "$url" in
    http://127.0.0.1:*) ;;
    # No usable address: stop the listener rather than wait out its timeout.
    *) kill "$pid" 2>/dev/null; wait "$pid" 2>/dev/null; rm -rf "$work"; return 1 ;;
  esac
  say "Opening the key page on your own computer: ${url}"
  say "If it did not open, open that address yourself in your browser."
  open_browser "$url" || true
  wait "$pid"
  KEY_PAGE_RESULT="$(cat "$out_file" 2>/dev/null)"
  rm -rf "$work"
  [ -n "$KEY_PAGE_RESULT" ]
}

# ------------------------------------------- the two credential moments (7/8) --
# Both are safe to call twice: each checks first and skips what is already done.
# That is what lets failure mode 13 run them one more time before stopping.

do_oauth_step() {
  step "Signing in to your main AI connection"
  say "In a moment a browser tab will open on OpenAI's own sign-in page."
  say "You are signing in to OpenAI directly — the sign-in happens between your browser and them, and nothing you type there passes through this installer or any server of ours."
  say "When you have finished signing in, come back to this window and it will carry on by itself."
  if [ "$DRY_RUN" = "1" ]; then
    log "Rehearsal run: skipping the browser sign-in."
    return 0
  fi
  if check_oauth_present; then
    log "You are already signed in — skipping."
    WORKING_PROVIDERS+=("openai-codex")
    return 0
  fi
  # FAILMODE 15: don't start a network step with no network.
  check_network || fail "there is no internet connection right now. Nothing you have done so far is lost — run this again when you are back online."
  # FAILMODE 8: if the browser never opens, print the address to open by hand.
  open_browser "https://auth.openai.com/device" || true
  if [ -n "$HERMES_BIN" ]; then
    "$HERMES_BIN" auth login openai >/dev/null 2>&1 || true
  fi
  # FAILMODE 9: tab closed or declined — offer one retry, then carry on.
  if ! check_oauth_present && [ -t 0 ]; then
    say "It looks like the sign-in was not completed. Would you like to try once more? [y/N]"
    read -r answer
    case "${answer:-n}" in
      y|Y)
        open_browser "https://auth.openai.com/device" || true
        [ -n "$HERMES_BIN" ] && "$HERMES_BIN" auth login openai >/dev/null 2>&1 || true
        ;;
    esac
  fi
  if check_oauth_present; then
    WORKING_PROVIDERS+=("openai-codex")
    note_done "your main AI connection"
  else
    log "Carrying on without the main connection. Your assistant will use the free backup models instead. That is a normal way to finish, not a failure."
  fi
  return 0
}

do_key_page_step() {
  local provider
  step "Your free backup connections"
  say "Next, a small page opens in your browser that is running on this computer and nowhere else."
  say "It asks for the free backup keys from OpenRouter and NVIDIA, and whatever you paste goes straight into your own settings file — it is never sent to us, never shown on screen, and never written into the log."
  say "If you would rather skip this, close the page and setup will finish without backups."
  if [ "$DRY_RUN" = "1" ]; then
    log "Rehearsal run: skipping the local key page."
    return 0
  fi
  if ! check_network; then
    log "No internet connection, so backup keys cannot be checked right now. Skipping this step; you can add them later by asking your assistant."
    return 0
  fi
  if start_key_page; then
    if printf '%s' "${KEY_PAGE_RESULT:-}" | grep -q '"submitted": true'; then
      for provider in openrouter nvidia; do
        if printf '%s' "$KEY_PAGE_RESULT" | grep -q "\"${provider}\"" ; then
          WORKING_PROVIDERS+=("$provider")
          log "Your ${provider} backup connection is set up and working."
        fi
      done
      note_done "your backup connections"
    else
      # FAILMODE 11: nothing submitted is a fine outcome.
      note_no_keys_submitted
    fi
    return 0
  fi
  # Last resort only: the local page could not start at all.
  if [ ! -t 0 ]; then
    note_no_keys_submitted
    return 0
  fi
  say "Paste your OpenRouter key here, or press Enter to skip (it will not be shown as you type):"
  read -rs typed_secret
  if [ -n "${typed_secret:-}" ] && probe_provider_key openrouter "$typed_secret"; then
    if store_secret "OPENROUTER_API_KEY" "$typed_secret" "$HERMES_ENV_FILE"; then
      WORKING_PROVIDERS+=("openrouter")
      log "Your openrouter backup connection is set up and working."
    else
      log "That backup connection could not be saved to ${HERMES_ENV_FILE}. Setup will carry on without it."
    fi
  fi
  unset typed_secret
  return 0
}

# ------------------------------------------------------------------- steps --

main() {
  say "Setting up your assistant."
  say "Re-running this is always safe. Nothing is ever deleted."

  # --- Step 1: the setup file from the web page (FAILMODE 3 handled inside).
  step "Reading your setup file"
  read_env_file "$ENV_FILE" || true

  # --- Step 2: resolve and create the base folder.
  step "Your assistant's folder"
  DEFAULT_BASE="$HOME/AI"
  if [ -z "$BASE" ] && [ -n "$ENV_BASE" ]; then
    BASE="$ENV_BASE"
  fi
  if [ -z "$BASE" ]; then
    # FAILMODE 3 (continued): with no setup file to tell us, ask. If nobody is
    # there to answer — a script, a pipe — fall straight through to the default.
    if [ -t 0 ] && [ "$CHECK_MODE" != "1" ]; then
      say "Where would you like your assistant to keep its folder?"
      say "Press Enter to use ${DEFAULT_BASE}, or type another location."
      read -r typed_base
      BASE="${typed_base:-$DEFAULT_BASE}"
    else
      BASE="$DEFAULT_BASE"
      say "Using the usual location: ${BASE}"
    fi
  fi
  # shellcheck disable=SC2034
  RERUN_COMMAND="$0 --base \"$BASE\""
  if [ -d "$BASE" ]; then
    say "Your folder is already there: ${BASE}"
  elif [ "$CHECK_MODE" = "1" ]; then
    say "Your folder does not exist yet: ${BASE}"
    say "Nothing was created — this is a check-only run."
    run_doctor
    exit 0
  else
    mkdir -p "$BASE" 2>/dev/null || true
  fi
  # FAILMODE 1: the folder has to be somewhere you can actually write. If the
  # chosen place will not take it, fall back to the usual location for this
  # computer and say where things went; stop only if that fails too.
  if [ ! -d "$BASE" ] || ! check_base_writable "$BASE"; then
    if [ "$CHECK_MODE" = "1" ]; then
      # Doctor mode changes nothing: say what a real run would do, then report.
      say "The folder ${BASE} cannot be written to."
      if [ "$BASE" != "$DEFAULT_BASE" ]; then
        say "A real run would fall back to the usual location for this computer: ${DEFAULT_BASE}"
      fi
      say "Nothing was created — this is a check-only run."
      run_doctor
      exit 1
    fi
    if [ "$BASE" != "$DEFAULT_BASE" ]; then
      say "The folder ${BASE} cannot be used — it may be read-only, or the disk may be full."
      say "Falling back to the usual location for this computer: ${DEFAULT_BASE}"
      BASE="$DEFAULT_BASE"
      # shellcheck disable=SC2034
      RERUN_COMMAND="$0 --base \"$BASE\""
      mkdir -p "$BASE" 2>/dev/null || true
    fi
    if [ ! -d "$BASE" ] || ! check_base_writable "$BASE"; then
      fail "the folder ${BASE} cannot be written to. It may be read-only, or the disk may be full. Pick a different location with --base and try again."
    fi
  fi
  note_done "your assistant's folder at ${BASE}"
  # FAILMODE 2: warn, never block, on cloud-synced locations.
  check_cloud_sync_path "$BASE" || true

  if [ "$CHECK_MODE" = "1" ]; then
    run_doctor
    exit $?
  fi

  # FAILMODE 17: if the last run was interrupted, everything below simply repeats.
  if was_interrupted "$BASE"; then
    log "Picking up where the last run left off. Every step checks itself first."
  else
    log "This folder was already set up once; re-checking everything."
  fi

  # --- Step 3: version history (FAILMODE 16 handled inside).
  step "Version history"
  ensure_git_repo "$BASE" && note_done "version history"

  # --- Step 4: unpack the files (FAILMODE 4 and 5 handled inside).
  step "Your assistant's files"
  resolve_source_dir || fail "the file bundle that should sit beside this script is missing. Download the zip again and unpack it before running this."
  protect_edited_files "$SOURCE_DIR" "$BASE"
  extract_missing_files "$SOURCE_DIR" "$BASE"
  note_done "your assistant's files"

  # --- Step 5: install Hermes (FAILMODE 6 and 7 handled inside).
  step "The program your assistant runs in"
  if [ "$DRY_RUN" = "1" ]; then
    log "Rehearsal run: skipping the Hermes install and the desktop build."
  elif ensure_hermes_installed; then
    note_done "Hermes"
    if [ -f "${HOME}/.hermes/desktop-built" ]; then
      log "The desktop app is already built — skipping."
    elif "$HERMES_BIN" desktop --build-only >/dev/null 2>&1; then
      mkdir -p "${HOME}/.hermes" && date -u '+%Y-%m-%dT%H:%M:%SZ' >"${HOME}/.hermes/desktop-built"
      log "Built the desktop app."
    else
      log "The desktop app did not build. The assistant still works from the terminal; you can ask it to try the desktop build again later."
    fi
  else
    fail "Hermes could not be installed. Install it by hand: curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash — then run this script again; it will pick up where it left off."
  fi

  # --- Step 6: settings (FAILMODE 14 handled inside).
  step "Your settings"
  merge_config "${SOURCE_DIR}/config-template.yaml" "$CONFIG_FILE"
  note_done "your settings file"

  # --- Step 7: the first credential moment — sign in with your browser.
  do_oauth_step
  do_key_page_step

  # --- Step 9: the setup file has done its job.
  step "Tidying up"
  if [ -f "$ENV_FILE" ]; then
    rm -f "$ENV_FILE" && log "Removed the setup file you downloaded; it is not needed any more."
  else
    log "The setup file is already gone — nothing to tidy."
  fi

  # --- Step 10: is anything actually working? (FAILMODE 13)
  step "Checking that your assistant can actually talk to something"
  if [ "$DRY_RUN" = "1" ]; then
    log "Rehearsal run: skipping the live connection check."
  elif ! any_provider_works; then
    # FAILMODE 13: nothing works yet — run both credential steps once more
    # before giving up, then stop honestly rather than hand over a dead assistant.
    say "Nothing is answering yet, so let us try the sign-in and the key page one more time."
    do_oauth_step
    do_key_page_step
    if ! any_provider_works; then
      fail "your assistant has no working AI connection, even after a second try, so handing it to you now would only waste your time. Run the command below to try again."
    fi
    note_done "a working AI connection"
  else
    note_done "a working AI connection"
  fi

  # --- Step 11: the full self-check, then the handoff.
  run_doctor || true
  mark_run_complete "$BASE"
  write_handoff
  say ""
  say "Setup finished."
  return 0
}

# ---------------------------------------------------------------- the doctor --
# Runs every check. In --check mode it writes nothing at all.

run_doctor() {
  local rc=0
  step "Full check"
  check_base_writable "$BASE" || { say "Check 1: the folder ${BASE} cannot be written to."; rc=1; }
  check_cloud_sync_path "$BASE" || true
  read_env_file "$ENV_FILE" || true
  if resolve_source_dir; then
    check_for_drift "$SOURCE_DIR" "$BASE" || rc=1        # covers checks 3, 4 and 18
    protect_edited_files "$SOURCE_DIR" "$BASE" || true   # check 5
  fi
  if command -v hermes >/dev/null 2>&1 || find_hermes_on_disk; then
    say "Hermes is installed."
  else
    say "Hermes is not installed yet."
    rc=1
  fi
  if [ "$DRY_RUN" != "1" ] && [ "$CHECK_MODE" = "1" ]; then
    check_network || { say "There is no internet connection right now."; rc=1; }
  fi
  ensure_git_repo "$BASE" || true
  merge_config "${SOURCE_DIR:-}/config-template.yaml" "$CONFIG_FILE"
  mark_run_complete "$BASE"
  return "$rc"
}

# ------------------------------------------------------------- the handoff --

write_handoff() {
  local out="${BASE}/MEET-YOUR-ASSISTANT.txt"
  local prompt_src="${SCRIPT_DIR}/lib/meet-prompt.txt"
  local prompt
  prompt="$(sed "s#<BASE>#${BASE}#g" "$prompt_src")"
  printf '%s\n' "$prompt" >"$out"
  say ""
  say "------------------------------------------------------------------"
  say "Copy everything between the lines and paste it into your assistant"
  say "------------------------------------------------------------------"
  say "$prompt"
  say "------------------------------------------------------------------"
  say "If the copy goes wrong, the same message is saved at ${out}"
}

# ------------------------------------------------------------------- start --

if [ "$DRY_RUN" = "1" ]; then
  CONFIG_FILE="${AIA_CONFIG:-${BASE:-$HOME/AI}/.hermes/config.yaml}"
else
  CONFIG_FILE="${AIA_CONFIG:-$HOME/.hermes/config.yaml}"
fi
HERMES_ENV_FILE="$(dirname "$CONFIG_FILE")/.env"
SOURCE_DIR=""
KEY_PAGE_RESULT=""

main
exit $?
