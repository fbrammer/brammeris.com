#!/usr/bin/env bash
# checks.sh — one function per failure mode from spec §2.7.
#
# These are the script-readable twin of CONTROL/SELF-CHECK.md: FAILMODE N here
# corresponds one-to-one with "### Check N" there.
#
# Every function follows: check -> skip if already correct -> do -> verify.
# No function ever prints, logs, or stores a credential.
#
# Sourced by aia-setup.sh. Expects these globals to exist:
#   BASE        resolved base folder
#   CHECK_MODE  1 when running --check (doctor mode: no writes at all)
#   DRY_RUN     1 when AIA_DRY_RUN=1 (no browsers, no servers, no installs)
#   SOURCE_DIR  folder holding the shipped aiaFFS content

# ---------------------------------------------------------------- utilities --

# Timestamped, credential-free line appended to CONTROL/setup-log.txt.
log() {
  local stamp line
  stamp="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  line="[${stamp}] $*"
  printf '%s\n' "$line"
  if [ "${CHECK_MODE:-0}" = "1" ]; then
    return 0
  fi
  if [ -d "${BASE:-}/CONTROL" ]; then
    printf '%s\n' "$line" >>"${BASE}/CONTROL/setup-log.txt" 2>/dev/null || true
  fi
}

# Plain-words stop. Says what failed, what already worked, and the re-run command.
fail() {
  local what="$1"
  printf '\n%s\n' "Setup stopped: ${what}"
  printf '%s\n' "What already finished successfully:"
  if [ "${#COMPLETED[@]}" -eq 0 ]; then
    printf '  %s\n' "(nothing yet — this failed on the first step)"
  else
    local item
    for item in "${COMPLETED[@]}"; do
      printf '  - %s\n' "$item"
    done
  fi
  printf '%s\n' "Nothing that finished has been lost. When you have dealt with the"
  printf '%s\n' "problem above, run this exact command again and it will pick up"
  printf '%s\n' "where it left off:"
  printf '\n  %s\n\n' "${RERUN_COMMAND}"
  exit 1
}

note_done() {
  COMPLETED+=("$1")
}

# sha256 of a file, portable across mac and linux.
hash_file() {
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$1" | awk '{print $1}'
  else
    sha256sum "$1" | awk '{print $1}'
  fi
}

# ------------------------------------------------------------- 1..18 checks --

# FAILMODE 1: base folder path invalid, unwritable, or on a full disk.
check_base_writable() {
  local base="$1"
  local probe="${base}/.aia-write-probe"
  if ! touch "$probe" 2>/dev/null; then
    return 1
  fi
  rm -f "$probe"
  return 0
}

# FAILMODE 2: base folder sits inside a cloud-sync folder. Warn only, never block.
check_cloud_sync_path() {
  local base="$1"
  case "$base" in
    *Dropbox*|*OneDrive*|*"Google Drive"*|*"Mobile Documents"*|*iCloud*)
      log "Note: your folder is inside a cloud-sync folder. That usually works, but sync can occasionally scramble the version history. Ask your assistant to move it if you would rather."
      return 1
      ;;
  esac
  return 0
}

# FAILMODE 3: env.txt missing, empty, or from an older page version. Never fatal.
read_env_file() {
  local path="$1"
  ENV_BASE=""
  ENV_PROVIDERS=""
  ENV_VERSION=""
  if [ ! -s "$path" ]; then
    log "No setup file found at ${path}; continuing with defaults."
    return 1
  fi
  local key value line
  while IFS= read -r line; do
    case "$line" in
      ''|'#'*) continue ;;
    esac
    key="${line%%=*}"
    value="${line#*=}"
    # ENV_BASE and ENV_PROVIDERS are read by the main script.
    # shellcheck disable=SC2034
    case "$key" in
      BASE) ENV_BASE="$value" ;;
      PROVIDERS) ENV_PROVIDERS="$value" ;;
      VERSION) ENV_VERSION="$value" ;;
    esac
  done <"$path"
  if [ -z "$ENV_VERSION" ]; then
    log "Setup file has no version stamp; treating it as an older one and using defaults where it is silent."
  fi
  return 0
}

# FAILMODE 4: a prior run stopped partway; some shipped files are missing.
# Re-extract only what is absent, leave everything else alone.
extract_missing_files() {
  local src="$1" dest="$2"
  local rel target copied=0 missing=0
  while IFS= read -r rel; do
    target="${dest}/${rel}"
    if [ -e "$target" ]; then
      continue
    fi
    missing=$((missing + 1))
    if [ "${CHECK_MODE:-0}" = "1" ]; then
      continue
    fi
    mkdir -p "$(dirname "$target")"
    cp "${src}/${rel}" "$target" && copied=$((copied + 1))
  done < <(cd "$src" && find . -type f ! -name '*.pyc' | sed 's|^\./||' | sort)
  if [ "$missing" -eq 0 ]; then
    log "Your assistant's files are already all in place — nothing to unpack."
  else
    log "Restored ${copied} of ${missing} file(s) that were missing from your folder."
  fi
  return 0
}

# FAILMODE 5: user edited a shipped file, then re-ran the installer.
# Never overwrite. Write <file>.new alongside and report it.
protect_edited_files() {
  local src="$1" dest="$2"
  local rel target changed=0
  while IFS= read -r rel; do
    target="${dest}/${rel}"
    [ -e "$target" ] || continue
    if [ "$(hash_file "$target")" = "$(hash_file "${src}/${rel}")" ]; then
      continue
    fi
    changed=$((changed + 1))
    if [ "${CHECK_MODE:-0}" = "1" ]; then
      log "You have edited ${rel}. A re-run would leave your version alone."
      continue
    fi
    cp "${src}/${rel}" "${target}.new"
    log "You had edited ${rel}, so it was left exactly as you have it. The newer shipped version is beside it as ${rel}.new — keep whichever you prefer."
  done < <(cd "$src" && find . -type f ! -name '*.pyc' | sed 's|^\./||' | sort)
  if [ "$changed" -eq 0 ]; then
    log "No shipped file has been edited; nothing needed protecting."
  fi
  return 0
}

# FAILMODE 6: Hermes not installed, or its install failed.
ensure_hermes_installed() {
  if command -v hermes >/dev/null 2>&1; then
    HERMES_BIN="$(command -v hermes)"
    log "Hermes is already installed — skipping that step."
    return 0
  fi
  if find_hermes_on_disk; then
    return 0
  fi
  if [ "${CHECK_MODE:-0}" = "1" ] || [ "${DRY_RUN:-0}" = "1" ]; then
    log "Hermes is not installed. A real run would install it now."
    return 1
  fi
  log "Installing Hermes. This is the program your assistant runs inside."
  if install_hermes_primary || install_hermes_alternate; then
    if command -v hermes >/dev/null 2>&1; then
      HERMES_BIN="$(command -v hermes)"
      log "Hermes installed."
      return 0
    fi
    # The installer places the binary under ~/.local/bin, which is not on
    # PATH for a freshly-installed, non-interactive shell — check on disk
    # before concluding the install failed. find_hermes_on_disk logs its own
    # "installed but can't be found by name" message and fixes the profile.
    if find_hermes_on_disk; then
      return 0
    fi
  fi
  return 1
}

install_hermes_primary() {
  # This is the real, only distribution channel: Nous Research's own installer.
  # There is no npm package or brew formula for Hermes Agent — it installs its
  # own venv and clones its source under ~/.hermes/hermes-agent. --skip-setup
  # skips its interactive wizard; our own setup takes over from there.
  command -v curl >/dev/null 2>&1 || return 1
  curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash -s -- --skip-setup >/dev/null 2>&1
}

install_hermes_alternate() {
  # No alternate channel exists; kept as a no-op so ensure_hermes_installed's
  # `install_hermes_primary || install_hermes_alternate` still reads clearly.
  return 1
}

# FAILMODE 7: Hermes is installed but the computer can't find it by name.
# Use its full location for this run and add that location to the shell profile.
find_hermes_on_disk() {
  local candidate
  for candidate in \
    "$HOME/.local/bin/hermes" \
    "$HOME/.npm-global/bin/hermes" \
    "/usr/local/bin/hermes" \
    "/opt/homebrew/bin/hermes"; do
    if [ -x "$candidate" ]; then
      HERMES_BIN="$candidate"
      log "Hermes is installed at ${candidate} but your shell cannot find it by name. Using the full location for this run."
      add_to_path_profile "$(dirname "$candidate")"
      return 0
    fi
  done
  return 1
}

add_to_path_profile() {
  local dir="$1" profile="${HOME}/.profile"
  [ -n "${ZSH_VERSION:-}" ] && profile="${HOME}/.zshrc"
  if [ "${CHECK_MODE:-0}" = "1" ] || [ "${DRY_RUN:-0}" = "1" ]; then
    return 0
  fi
  if [ -f "$profile" ] && grep -qF "$dir" "$profile" 2>/dev/null; then
    log "Your shell profile already knows about ${dir}."
    return 0
  fi
  printf '\n# added by the assistant installer\nexport PATH="%s:$PATH"\n' "$dir" >>"$profile"
  log "Added ${dir} to ${profile} so future runs find Hermes by name."
}

# FAILMODE 8: the sign-in browser window never opened.
open_browser() {
  local url="$1"
  if [ "${DRY_RUN:-0}" = "1" ] || [ "${CHECK_MODE:-0}" = "1" ]; then
    return 0
  fi
  if command -v open >/dev/null 2>&1; then
    open "$url" >/dev/null 2>&1 && return 0
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$url" >/dev/null 2>&1 && return 0
  fi
  printf '%s\n' "Your browser did not open on its own. Open this address yourself:"
  printf '  %s\n' "$url"
  return 1
}

# FAILMODE 9: user closed the sign-in tab or declined it.
# Offer one retry; otherwise continue on free fallbacks only — a supported ending.
check_oauth_present() {
  if [ "${DRY_RUN:-0}" = "1" ]; then
    return 1
  fi
  [ -n "${HERMES_BIN:-}" ] || return 1
  "$HERMES_BIN" auth list 2>/dev/null | grep -qi 'openai\|codex'
}

# FAILMODE 10: the loopback page's port was already in use.
# Bind 127.0.0.1:0 so the kernel picks a free port; retry a few times, and only
# as a last resort ask for the key in the terminal instead.
start_key_page() {
  local attempt
  for attempt in 1 2 3 4 5; do
    if run_key_page_once; then
      return 0
    fi
    log "The local sign-in page could not start (attempt ${attempt} of 5). Trying another port."
  done
  log "Could not open a local page for your backup keys. Falling back to typing them in here."
  return 1
}

# FAILMODE 11: the user submits nothing on the key page, or closes it.
# Not an error — continue with whatever was actually provided.
note_no_keys_submitted() {
  log "No backup keys were entered. That is fine — your assistant will use its main connection, and you can add backups later by asking it to."
}

# FAILMODE 12: a pasted key is malformed or wrong.
# Live one-shot probe against the provider before anything is written.
probe_provider_key() {
  # The endpoint has to be one that actually requires the key: both providers'
  # /v1/models are public and answer 200 to anything at all.
  # Success statuses are scoped per provider on purpose. A blanket
  # 200|2??|400|404|405|422 would mean a retired NVIDIA model id (a 404/422)
  # reports every key as "working" forever, and would let an unexpected
  # openrouter status pass a bad key.
  local provider="$1" secret="$2" url status extra="" ok=""
  case "$provider" in
    # Dedicated key-info endpoint: only a clean 200 means the key is good.
    openrouter) url="https://openrouter.ai/api/v1/key"; ok="200" ;;
    # NVIDIA has no key-info endpoint, so the cheapest key-requiring call is a
    # one-token completion. Same pair the Python page uses.
    nvidia)
      url="https://integrate.api.nvidia.com/v1/chat/completions"
      extra='header = "Content-Type: application/json"
data = "{\"model\":\"meta/llama-3.1-8b-instruct\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}],\"max_tokens\":1}"'
      # A malformed-but-authenticated completion can legitimately 400/422 with a
      # good key. 404 is NOT accepted: that is what a retired model id returns,
      # and it must surface rather than masquerade as a working key.
      ok="200 400 422"
      ;;
    *)          return 1 ;;
  esac
  [ -n "$secret" ] || return 1
  command -v curl >/dev/null 2>&1 || return 1
  # The key goes in on stdin as a curl config file, never as an argument, so it
  # is never visible to other processes through `ps`.
  status="$(printf 'silent\noutput = "/dev/null"\nwrite-out = "%%{http_code}"\nmax-time = 20\nheader = "Authorization: Bearer %s"\nurl = "%s"\n%s\n' \
    "$secret" "$url" "$extra" | curl --config - 2>/dev/null || true)"
  # $ok is a space-separated list of the statuses that mean "the key works"
  # for this provider; anything else (401/403 included) means it does not.
  case " ${ok} " in
    *" ${status} "*) return 0 ;;
    *) return 1 ;;
  esac
}

# Writes one credential into Hermes's own environment file, which is where
# Hermes reads the values that config.yaml names through `api_key_env`.
# Created with restrictive permissions before anything is written into it, and
# never truncated: existing lines for other providers are preserved.
# Returns non-zero if the write did not actually happen.
store_secret() {
  local var="$1" secret="$2" file="$3" dir
  dir="$(dirname "$file")"
  mkdir -p "$dir" || return 1
  (
    umask 077
    : >"${file}.tmp" || exit 1
    if [ -f "$file" ]; then
      grep -v "^${var}=" "$file" >>"${file}.tmp" || true
    fi
    printf '%s=%s\n' "$var" "$secret" >>"${file}.tmp" || exit 1
    mv "${file}.tmp" "$file" || exit 1
  ) || { rm -f "${file}.tmp"; return 1; }
  chmod 600 "$file" 2>/dev/null || true
  grep -q "^${var}=" "$file" 2>/dev/null
}

# FAILMODE 13: no provider at all ends up working.
# Stop before the handoff — a broken assistant is worse than an honest stop.
any_provider_works() {
  local ok=1 p
  if check_oauth_present; then
    ok=0
  fi
  for p in "${WORKING_PROVIDERS[@]:-}"; do
    [ -n "$p" ] && ok=0
  done
  return "$ok"
}

# FAILMODE 14: config.yaml already exists, possibly with the user's own edits.
# Merge in only the missing top-level keys; never clobber a value they have.
merge_config() {
  local template="$1" target="$2"
  local key kept=0 added=0 in_block=0 line
  if [ ! -f "$template" ]; then
    log "The starting settings template could not be found, so your settings file was left exactly as it is."
    return 1
  fi
  if [ ! -f "$target" ]; then
    if [ "${CHECK_MODE:-0}" = "1" ]; then
      log "No settings file yet; a real run would create one."
      return 0
    fi
    if ! mkdir -p "$(dirname "$target")" || ! cp "$template" "$target"; then
      log "Your starting settings could not be written to ${target}."
      return 1
    fi
    chmod 600 "$target"
    log "Wrote your starting settings to ${target}."
    return 0
  fi
  while IFS= read -r line; do
    case "$line" in
      [a-zA-Z]*:*) key="${line%%:*}" ;;
      *) continue ;;
    esac
    if grep -q "^${key}:" "$target" 2>/dev/null; then
      kept=$((kept + 1))
      continue
    fi
    added=$((added + 1))
    if [ "${CHECK_MODE:-0}" = "1" ]; then
      continue
    fi
    in_block=0
    while IFS= read -r l2; do
      if [ "$in_block" = "1" ]; then
        case "$l2" in
          [a-zA-Z]*:*) break ;;
        esac
        printf '%s\n' "$l2" >>"$target"
      elif [ "$l2" = "$line" ]; then
        printf '\n%s\n' "$l2" >>"$target"
        in_block=1
      fi
    done <"$template"
  done <"$template"
  log "Your settings file was already there. ${kept} setting(s) you already had were left exactly as they are; ${added} missing one(s) were added."
  return 0
}

# FAILMODE 15: no network connection mid-run. Wait, retry once, then stop cleanly.
check_network() {
  local attempt
  command -v curl >/dev/null 2>&1 || return 0
  for attempt in 1 2; do
    if curl -s -o /dev/null --max-time 10 https://api.openai.com/ 2>/dev/null; then
      return 0
    fi
    [ "$attempt" = "1" ] && sleep 3
  done
  return 1
}

# FAILMODE 16: git init fails because git itself is missing. Non-fatal, warn once.
ensure_git_repo() {
  local base="$1"
  if [ -d "${base}/.git" ]; then
    log "Version history is already set up in this folder — skipping."
    return 0
  fi
  if ! command -v git >/dev/null 2>&1; then
    log "Version history is not available because git is not installed on this computer. Everything else works; your assistant can offer to set this up later."
    return 1
  fi
  if [ "${CHECK_MODE:-0}" = "1" ]; then
    log "Version history is not set up yet; a real run would start it."
    return 0
  fi
  if git -C "$base" init --quiet >/dev/null 2>&1 && [ -d "${base}/.git" ]; then
    log "Started version history in your folder, so nothing can be lost."
    return 0
  fi
  log "Could not start version history here. Everything else still works."
  return 1
}

# FAILMODE 17: the run was interrupted partway (Ctrl-C, closed window, power loss).
# Nothing extra to detect: every step above is safe to repeat, so re-running the
# whole checklist is the fix. This marker records that the run reached the end.
mark_run_complete() {
  local base="$1"
  if [ "${CHECK_MODE:-0}" = "1" ]; then
    if [ -f "${base}/CONTROL/.setup-complete" ]; then
      log "A previous setup run finished all the way through."
    else
      log "No completed setup run on record — the last one may have been interrupted. Re-running is safe."
    fi
    return 0
  fi
  mkdir -p "${base}/CONTROL"
  date -u '+%Y-%m-%dT%H:%M:%SZ' >"${base}/CONTROL/.setup-complete"
}

was_interrupted() {
  [ ! -f "${1}/CONTROL/.setup-complete" ]
}

# FAILMODE 18: drift — a shipped file moved, renamed, or deleted after setup.
# Same inventory as failure mode 4, but runnable at any time, not just at setup.
check_for_drift() {
  local src="$1" dest="$2"
  local rel gone=0
  while IFS= read -r rel; do
    if [ ! -e "${dest}/${rel}" ]; then
      gone=$((gone + 1))
      log "Missing from your folder: ${rel}"
    fi
  done < <(cd "$src" && find . -type f ! -name '*.pyc' | sed 's|^\./||' | sort)
  if [ "$gone" -eq 0 ]; then
    log "Every file that should be in your folder is there."
    return 0
  fi
  log "${gone} file(s) are missing. Re-running setup puts them back, or ask your assistant to restore them from version history."
  return 1
}
