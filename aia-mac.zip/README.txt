This zip contains the AI-Assistant folder system for mac, ready to be installed on your computer.
Run aia-setup.sh to set everything up.
It is safe to run this script more than once; it will not duplicate or damage anything already installed.
If something goes wrong, check CONTROL/setup-log.txt for details, and the self-check the script runs will tell you what to fix.
