# checks.ps1 — one function per failure mode from spec §2.7.
#
# The Windows twin of lib/checks.sh. FAILMODE N here corresponds one-to-one with
# "### Check N" in CONTROL/SELF-CHECK.md and with "# FAILMODE N:" in checks.sh.
#
# Every function follows: check -> skip if already correct -> do -> verify.
# No function ever prints, logs, or stores a credential.
#
# Dot-sourced by aia-setup.ps1. Expects these script-scope variables to exist:
#   $script:Base       resolved base folder
#   $script:CheckMode  $true when running -Check (doctor mode: no writes at all)
#   $script:DryRun     $true when $env:AIA_DRY_RUN -eq '1'
#   $script:SourceDir  folder holding the shipped aiaFFS content

Set-StrictMode -Version Latest

# Make sure TLS 1.2 is on the table before the first network call.
#
# Windows PowerShell 5.1 on an older .NET Framework — or one without
# SchUseStrongCrypto — defaults to a protocol set that excludes TLS 1.2, and both
# openrouter.ai and api.openai.com speak nothing else. On such a machine every
# probe would fail as a WebException carrying no response at all, which is exactly
# the silent "no internet" / "that key did not work" symptom, just from a
# different root cause.
#
# -bor, not a plain assignment: this adds TLS 1.2 to whatever is already enabled
# rather than replacing the host's own choices. Wrapped in try/catch because some
# hosts already set this, and some lock it down.
try {
    [System.Net.ServicePointManager]::SecurityProtocol =
        [System.Net.ServicePointManager]::SecurityProtocol -bor [System.Net.SecurityProtocolType]::Tls12
} catch { }

# ---------------------------------------------------------------- utilities --

function Get-Stamp {
    (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
}

# Timestamped, credential-free line appended to CONTROL/setup-log.txt.
function Write-Log {
    param([string]$Message)
    $line = "[{0}] {1}" -f (Get-Stamp), $Message
    Write-Host $line
    if ($script:CheckMode) { return }
    $controlDir = Join-Path $script:Base 'CONTROL'
    if ($script:Base -and (Test-Path -LiteralPath $controlDir -PathType Container)) {
        try {
            Add-Content -LiteralPath (Join-Path $controlDir 'setup-log.txt') -Value $line -Encoding utf8
        } catch { }
    }
}

function Write-Say {
    param([string]$Message = '')
    Write-Host $Message
}

function Write-Step {
    param([string]$Message)
    Write-Host ''
    Write-Host ("== " + $Message)
}

# Plain-words stop. Says what failed, what already worked, and the re-run command.
function Stop-Setup {
    param([string]$What)
    Write-Host ''
    Write-Host ("Setup stopped: " + $What)
    Write-Host 'What already finished successfully:'
    if (-not $script:Completed -or $script:Completed.Count -eq 0) {
        Write-Host '  (nothing yet — this failed on the first step)'
    } else {
        foreach ($item in $script:Completed) { Write-Host ("  - " + $item) }
    }
    Write-Host 'Nothing that finished has been lost. When you have dealt with the'
    Write-Host 'problem above, run this exact command again and it will pick up'
    Write-Host 'where it left off:'
    Write-Host ''
    Write-Host ("  " + $script:RerunCommand)
    Write-Host ''
    exit 1
}

function Add-Completed {
    param([string]$What)
    $script:Completed += $What
}

# The equivalent of bash's `[ -t 0 ]`: is there really a person at the keyboard?
# [Environment]::UserInteractive alone is not enough — it stays $true when stdin
# has been piped or redirected, which is exactly the case where bash would fall
# through to the default instead of asking. Checking IsInputRedirected as well
# keeps Read-Host from blocking, or from eating piped input meant for something else.
function Test-Interactive {
    try {
        if ([Console]::IsInputRedirected) { return $false }
    } catch { }
    return [Environment]::UserInteractive
}

function Get-FileSha256 {
    param([string]$Path)
    try { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
    catch { '' }
}

# Relative paths of every shipped file, in a stable order. The Windows twin of
# checks.sh's `find . -type f ! -name '*.pyc'`.
function Get-ShippedFiles {
    param([string]$Source)
    if (-not (Test-Path -LiteralPath $Source -PathType Container)) { return @() }
    $root = (Resolve-Path -LiteralPath $Source).ProviderPath.TrimEnd('\')
    Get-ChildItem -LiteralPath $root -Recurse -File -Force |
        Where-Object { $_.Extension -ne '.pyc' } |
        ForEach-Object { $_.FullName.Substring($root.Length + 1) } |
        Sort-Object
}

# ------------------------------------------------------------- 1..18 checks --

# FAILMODE 1: base folder path invalid, unwritable, or on a full disk.
function Test-BaseWritable {
    param([string]$Path)
    if (-not $Path) { return $false }
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { return $false }
    $probe = Join-Path $Path '.aia-write-probe'
    try {
        [System.IO.File]::WriteAllText($probe, '')
        Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
        return $true
    } catch {
        return $false
    }
}

# FAILMODE 2: base folder sits inside a cloud-sync folder. Warn only, never block.
function Test-CloudSyncPath {
    param([string]$Path)
    $markers = @('Dropbox', 'OneDrive', 'Google Drive', 'iCloudDrive', 'iCloud Drive', 'Box Sync')
    foreach ($marker in $markers) {
        if ($Path -like ("*" + $marker + "*")) {
            Write-Log 'Note: your folder is inside a cloud-sync folder. That usually works, but sync can occasionally scramble the version history. Ask your assistant to move it if you would rather.'
            return $false
        }
    }
    return $true
}

# FAILMODE 3: env.txt missing, empty, or from an older page version. Never fatal.
function Read-SetupEnvFile {
    param([string]$Path)
    $script:EnvBase = ''
    $script:EnvProviders = ''
    $script:EnvVersion = ''
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf) -or
        (Get-Item -LiteralPath $Path).Length -eq 0) {
        Write-Log ("No setup file found at {0}; continuing with defaults." -f $Path)
        return $false
    }
    foreach ($line in [System.IO.File]::ReadAllLines($Path)) {
        if (-not $line -or $line.StartsWith('#')) { continue }
        $split = $line.IndexOf('=')
        if ($split -lt 1) { continue }
        $key = $line.Substring(0, $split)
        $value = $line.Substring($split + 1)
        switch ($key) {
            'BASE'      { $script:EnvBase = $value }
            'PROVIDERS' { $script:EnvProviders = $value }
            'VERSION'   { $script:EnvVersion = $value }
        }
    }
    if (-not $script:EnvVersion) {
        Write-Log 'Setup file has no version stamp; treating it as an older one and using defaults where it is silent.'
    }
    return $true
}

# FAILMODE 4: a prior run stopped partway; some shipped files are missing.
# Re-extract only what is absent, leave everything else alone.
function Restore-MissingFiles {
    param([string]$Source, [string]$Destination)
    $copied = 0
    $missing = 0
    foreach ($rel in Get-ShippedFiles $Source) {
        $target = Join-Path $Destination $rel
        if (Test-Path -LiteralPath $target) { continue }
        $missing++
        if ($script:CheckMode) { continue }
        $parent = Split-Path -Parent $target
        if ($parent -and -not (Test-Path -LiteralPath $parent -PathType Container)) {
            New-Item -ItemType Directory -Path $parent -Force | Out-Null
        }
        try {
            Copy-Item -LiteralPath (Join-Path $Source $rel) -Destination $target -Force
            $copied++
        } catch { }
    }
    if ($missing -eq 0) {
        Write-Log "Your assistant's files are already all in place — nothing to unpack."
    } else {
        Write-Log ("Restored {0} of {1} file(s) that were missing from your folder." -f $copied, $missing)
    }
    return $true
}

# FAILMODE 5: user edited a shipped file, then re-ran the installer.
# Never overwrite. Write <file>.new alongside and report it.
function Protect-EditedFiles {
    param([string]$Source, [string]$Destination)
    $changed = 0
    foreach ($rel in Get-ShippedFiles $Source) {
        $target = Join-Path $Destination $rel
        if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { continue }
        if ((Get-FileSha256 $target) -eq (Get-FileSha256 (Join-Path $Source $rel))) { continue }
        $changed++
        if ($script:CheckMode) {
            Write-Log ("You have edited {0}. A re-run would leave your version alone." -f $rel)
            continue
        }
        try { Copy-Item -LiteralPath (Join-Path $Source $rel) -Destination ($target + '.new') -Force } catch { }
        Write-Log ("You had edited {0}, so it was left exactly as you have it. The newer shipped version is beside it as {0}.new — keep whichever you prefer." -f $rel)
    }
    if ($changed -eq 0) {
        Write-Log 'No shipped file has been edited; nothing needed protecting.'
    }
    return $true
}

# FAILMODE 6: Hermes not installed, or its install failed.
function Install-HermesIfNeeded {
    $found = Get-Command hermes -ErrorAction SilentlyContinue
    if ($found) {
        $script:HermesBin = $found.Source
        Write-Log 'Hermes is already installed — skipping that step.'
        return $true
    }
    if (Find-HermesOnDisk) { return $true }
    if ($script:CheckMode -or $script:DryRun) {
        Write-Log 'Hermes is not installed. A real run would install it now.'
        return $false
    }
    Write-Log 'Installing Hermes. This is the program your assistant runs inside.'
    if ((Install-HermesPrimary) -or (Install-HermesAlternate)) {
        $found = Get-Command hermes -ErrorAction SilentlyContinue
        if ($found) {
            $script:HermesBin = $found.Source
            Write-Log 'Hermes installed.'
            return $true
        }
        if (Find-HermesOnDisk) { return $true }
    }
    return $false
}

function Install-HermesPrimary {
    # This is the real, only distribution channel: Nous Research's own
    # PowerShell installer (no admin needed). There is no npm package or
    # winget id for Hermes Agent — it clones its source and builds its own
    # venv under %LOCALAPPDATA%\hermes\hermes-agent. -SkipSetup skips its
    # post-install wizard; our own setup takes over from there.
    try {
        $installScript = Invoke-RestMethod 'https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.ps1'
        & ([scriptblock]::Create($installScript)) -SkipSetup *> $null
        return $true
    } catch { return $false }
}

function Install-HermesAlternate {
    # No alternate channel exists; kept as a no-op so Install-HermesIfNeeded's
    # `(Install-HermesPrimary) -or (Install-HermesAlternate)` still reads clearly.
    return $false
}

# FAILMODE 7: Hermes is installed but the computer can't find it by name.
# Use its full location for this run and add that location to the user's PATH.
function Find-HermesOnDisk {
    $candidates = @(
        # The real install path: bin\hermes.exe, copied there from
        # venv\Scripts\hermes.exe by the installer, is what it adds to PATH.
        (Join-Path $env:LOCALAPPDATA 'hermes\hermes-agent\bin\hermes.exe'),
        (Join-Path $env:APPDATA 'npm\hermes.cmd'),
        (Join-Path $env:APPDATA 'npm\hermes.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\hermes\hermes.exe'),
        (Join-Path $env:ProgramFiles 'Hermes\hermes.exe'),
        (Join-Path $env:USERPROFILE '.local\bin\hermes.exe'),
        (Join-Path $env:USERPROFILE 'scoop\shims\hermes.exe')
    )
    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            $script:HermesBin = $candidate
            Write-Log ("Hermes is installed at {0} but your shell cannot find it by name. Using the full location for this run." -f $candidate)
            Add-DirectoryToUserPath (Split-Path -Parent $candidate)
            return $true
        }
    }
    return $false
}

function Add-DirectoryToUserPath {
    param([string]$Directory)
    if ($script:CheckMode -or $script:DryRun) { return }
    try {
        $current = [Environment]::GetEnvironmentVariable('Path', 'User')
        if (-not $current) { $current = '' }
        $parts = $current.Split(';') | Where-Object { $_ }
        if ($parts -contains $Directory) {
            Write-Log ("Your user PATH already knows about {0}." -f $Directory)
            return
        }
        $updated = if ($current) { $current.TrimEnd(';') + ';' + $Directory } else { $Directory }
        [Environment]::SetEnvironmentVariable('Path', $updated, 'User')
        $env:Path = $env:Path + ';' + $Directory
        Write-Log ("Added {0} to your user PATH so future runs find Hermes by name." -f $Directory)
    } catch {
        Write-Log ("Could not add {0} to your user PATH. Everything else still works." -f $Directory)
    }
}

# FAILMODE 8: the sign-in browser window never opened.
function Open-InBrowser {
    param([string]$Url)
    if ($script:DryRun -or $script:CheckMode) { return $true }
    try {
        Start-Process -FilePath $Url -ErrorAction Stop | Out-Null
        return $true
    } catch { }
    try {
        Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', 'start', '""', $Url -WindowStyle Hidden -ErrorAction Stop | Out-Null
        return $true
    } catch { }
    Write-Host 'Your browser did not open on its own. Open this address yourself:'
    Write-Host ("  " + $Url)
    return $false
}

# FAILMODE 9: user closed the sign-in tab or declined it.
# Offer one retry; otherwise continue on free fallbacks only — a supported ending.
function Test-OAuthPresent {
    if ($script:DryRun) { return $false }
    if (-not $script:HermesBin) { return $false }
    try {
        $out = & $script:HermesBin auth list 2>$null | Out-String
        return ($out -match '(?i)openai|codex')
    } catch { return $false }
}

# FAILMODE 10: the loopback page's port was already in use.
# Bind 127.0.0.1 on a kernel-chosen port; retry a few times, and only as a last
# resort ask for the key in the terminal instead.
function Start-KeyPage {
    for ($attempt = 1; $attempt -le 5; $attempt++) {
        if (Invoke-KeyPageOnce) { return $true }
        Write-Log ("The local sign-in page could not start (attempt {0} of 5). Trying another port." -f $attempt)
    }
    Write-Log 'Could not open a local page for your backup keys. Falling back to typing them in here.'
    return $false
}

# FAILMODE 11: the user submits nothing on the key page, or closes it.
# Not an error — continue with whatever was actually provided.
function Write-NoKeysSubmitted {
    Write-Log 'No backup keys were entered. That is fine — your assistant will use its main connection, and you can add backups later by asking it to.'
}

# FAILMODE 12: a pasted key is malformed or wrong.
# Live one-shot probe against the provider before anything is written.
#
# The secret travels as an in-process HTTP header on a .NET HttpWebRequest. It is
# never placed on any command line, so it can never be read out of a process
# listing by another user on this machine.
#
# HttpWebRequest, not HttpClient, on purpose: System.Net.Http is not preloaded in
# Windows PowerShell 5.1 — the very interpreter this installer tells people to
# launch with "right-click → Run with PowerShell" — so touching those types there
# throws a type-load error. That error would be swallowed by the catch below and
# come back as "wrong key" for every valid key, and as "no internet" from
# Test-Network on a perfectly healthy machine. System.Net lives in the always-
# loaded framework assemblies and needs no Add-Type on any host.
function Test-ProviderKey {
    param(
        [string]$Provider,
        [string]$Secret
    )
    if (-not $Secret) { return $false }
    $url = $null
    $payload = $null
    switch ($Provider) {
        # openrouter/nvidia /v1/models are public and answer 200 to any nonsense,
        # which would make failure mode 12 useless. These endpoints need the key.
        'openrouter' { $url = 'https://openrouter.ai/api/v1/key' }
        'nvidia' {
            $url = 'https://integrate.api.nvidia.com/v1/chat/completions'
            $payload = '{"model":"meta/llama-3.1-8b-instruct","messages":[{"role":"user","content":"hi"}],"max_tokens":1}'
        }
        default { return $false }
    }
    try {
        $request = [System.Net.WebRequest]::Create($url)
        $request.Timeout = 20000
        $request.Headers['Authorization'] = 'Bearer ' + $Secret
        if ($payload) {
            $request.Method = 'POST'
            $request.ContentType = 'application/json'
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($payload)
            $request.ContentLength = $bytes.Length
            $stream = $request.GetRequestStream()
            $stream.Write($bytes, 0, $bytes.Length)
            $stream.Close()
        } else {
            $request.Method = 'GET'
        }
        $response = $request.GetResponse()
        $code = [int]$response.StatusCode
        $response.Close()
        # Only 401/403 mean the key itself is wrong; anything else means it got through.
        return ($code -ne 401 -and $code -ne 403)
    } catch [System.Net.WebException] {
        # A 4xx arrives here as an exception that still carries the real response.
        # Anything other than 401/403 means the key was accepted and only the
        # request itself was disliked. A transport failure with no response at all
        # tells us nothing, so treat that as a failure rather than write an
        # unverified key.
        $webResponse = $null
        try { $webResponse = $_.Exception.Response } catch { }
        if ($webResponse) {
            $code = [int]$webResponse.StatusCode
            try { $webResponse.Close() } catch { }
            return ($code -ne 401 -and $code -ne 403)
        }
        return $false
    } catch {
        return $false
    }
}

# Writes one credential into Hermes's own environment file (see
# Set-ConfigPaths in aia-setup.ps1 for where that actually lives on native
# Windows), which is where Hermes reads the values config.yaml names through
# `api_key_env`.
#
# Windows has no chmod, so the equivalent is icacls: the staging file is locked to
# the current user with inheritance removed *before* any secret is written into it,
# and the move preserves that ACL — there is never a moment where the file exists
# at looser permissions. Existing lines for other providers are preserved, never
# truncated. Line endings are LF, which is what Hermes's .env parser expects.
# Returns $false if the write did not actually happen.
function Save-Secret {
    param(
        [string]$Name,
        [string]$Secret,
        [string]$File
    )
    if ($script:CheckMode) { return $false }
    $dir = Split-Path -Parent $File
    $temp = $File + '.tmp'
    try {
        if (-not (Test-Path -LiteralPath $dir -PathType Container)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }
        Protect-PathToCurrentUser $dir $true

        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force }
        # Create empty, lock it down, and only then write the secret into it.
        [System.IO.File]::WriteAllText($temp, '')
        Protect-PathToCurrentUser $temp $false

        $kept = @()
        if (Test-Path -LiteralPath $File -PathType Leaf) {
            foreach ($line in [System.IO.File]::ReadAllLines($File)) {
                if ($line -notlike ($Name + '=*')) { $kept += $line }
            }
        }
        $kept = @($kept | Where-Object { $_ -ne '' })
        $kept += ($Name + '=' + $Secret)
        [System.IO.File]::WriteAllText($temp, ($kept -join "`n") + "`n")

        # File.Move's overwrite overload only exists on .NET Core; Windows
        # PowerShell 5.1 needs Move-Item. The staged file already carries the
        # restrictive ACL, and a move keeps it, so there is no loose-permission
        # window at any point on either path.
        try {
            [System.IO.File]::Move($temp, $File, $true)
        } catch [System.Management.Automation.MethodException] {
            Move-Item -LiteralPath $temp -Destination $File -Force
        } catch {
            Move-Item -LiteralPath $temp -Destination $File -Force
        }
        Protect-PathToCurrentUser $File $false

        # Verify the write actually landed before anyone calls this provider working.
        foreach ($line in [System.IO.File]::ReadAllLines($File)) {
            if ($line -like ($Name + '=*')) { return $true }
        }
        return $false
    } catch {
        try { if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force } } catch { }
        return $false
    }
}

# The Windows stand-in for `chmod 600` / `umask 077`: strip inheritance and grant
# only the current user. Applied at creation time, never as an afterthought.
#
# Both mechanisms run, in this order, and both are authoritative on their own:
#   1. icacls, the tool most Windows admins would reach for and the one whose
#      effect is easiest to verify by hand afterwards;
#   2. .NET Set-Acl, which runs unconditionally straight after and sets exactly
#      the same protection in-process. It is not a mere fallback — it is what
#      guarantees the lockdown even if icacls is absent, blocked by policy, or
#      quietly refuses the path.
# The grant string carries no embedded double-quotes: PowerShell 5.1 re-quotes
# native-command arguments, and literal quotes inside one arrive at icacls
# mangled (as \"...\"), which makes the grant silently fail. Passing the plain
# string lets PowerShell quote the whole argument correctly by itself.
function Protect-PathToCurrentUser {
    param([string]$Path, [bool]$IsDirectory)
    $account = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    $grant = if ($IsDirectory) { "${account}:(OI)(CI)F" } else { "${account}:F" }
    try {
        & icacls $Path /inheritance:r /grant:r $grant *> $null
    } catch { }
    try {
        $acl = Get-Acl -LiteralPath $Path
        $acl.SetAccessRuleProtection($true, $false)
        foreach ($rule in @($acl.Access)) { [void]$acl.RemoveAccessRule($rule) }
        $rights = if ($IsDirectory) { 'FullControl' } else { 'FullControl' }
        $inherit = if ($IsDirectory) { 'ContainerInherit,ObjectInherit' } else { 'None' }
        $acl.AddAccessRule([System.Security.AccessControl.FileSystemAccessRule]::new(
            $account, $rights, $inherit, 'None', 'Allow'))
        Set-Acl -LiteralPath $Path -AclObject $acl
    } catch { }
}

# FAILMODE 13: no provider at all ends up working.
# Stop before the handoff — a broken assistant is worse than an honest stop.
function Test-AnyProviderWorks {
    if (Test-OAuthPresent) { return $true }
    foreach ($p in $script:WorkingProviders) {
        if ($p) { return $true }
    }
    return $false
}

# FAILMODE 14: config.yaml already exists, possibly with the user's own edits.
# Merge in only the missing top-level keys; never clobber a value they have.
function Merge-Config {
    param([string]$Template, [string]$Target)
    if (-not $Template -or -not (Test-Path -LiteralPath $Template -PathType Leaf)) {
        Write-Log 'The starting settings template could not be found, so your settings file was left exactly as it is.'
        return $false
    }
    if (-not (Test-Path -LiteralPath $Target -PathType Leaf)) {
        if ($script:CheckMode) {
            Write-Log 'No settings file yet; a real run would create one.'
            return $true
        }
        try {
            $dir = Split-Path -Parent $Target
            if (-not (Test-Path -LiteralPath $dir -PathType Container)) {
                New-Item -ItemType Directory -Path $dir -Force | Out-Null
            }
            Protect-PathToCurrentUser $dir $true
            Copy-Item -LiteralPath $Template -Destination $Target -Force
            Protect-PathToCurrentUser $Target $false
        } catch {
            Write-Log ("Your starting settings could not be written to {0}." -f $Target)
            return $false
        }
        Write-Log ("Wrote your starting settings to {0}." -f $Target)
        return $true
    }

    $templateLines = [System.IO.File]::ReadAllLines($Template)
    $existing = [System.IO.File]::ReadAllLines($Target)
    $kept = 0
    $added = 0
    $toAppend = @()
    for ($i = 0; $i -lt $templateLines.Count; $i++) {
        $line = $templateLines[$i]
        if ($line -notmatch '^[A-Za-z][^:]*:') { continue }
        $key = $line.Substring(0, $line.IndexOf(':'))
        $have = $false
        foreach ($e in $existing) { if ($e -like ($key + ':*')) { $have = $true; break } }
        if ($have) { $kept++; continue }
        $added++
        if ($script:CheckMode) { continue }
        $toAppend += ''
        $toAppend += $line
        for ($j = $i + 1; $j -lt $templateLines.Count; $j++) {
            if ($templateLines[$j] -match '^[A-Za-z][^:]*:') { break }
            $toAppend += $templateLines[$j]
        }
    }
    if ($toAppend.Count -gt 0 -and -not $script:CheckMode) {
        try {
            [System.IO.File]::AppendAllText($Target, ($toAppend -join "`n") + "`n")
        } catch {
            Write-Log ("Could not update {0}; it was left exactly as it is." -f $Target)
            return $false
        }
    }
    Write-Log ("Your settings file was already there. {0} setting(s) you already had were left exactly as they are; {1} missing one(s) were added." -f $kept, $added)
    return $true
}

# FAILMODE 15: no network connection mid-run. Wait, retry once, then stop cleanly.
# Same reasoning as Test-ProviderKey: System.Net.WebRequest, never System.Net.Http,
# so this cannot report "no internet" because of a missing assembly.
function Test-Network {
    for ($attempt = 1; $attempt -le 2; $attempt++) {
        try {
            $request = [System.Net.WebRequest]::Create('https://api.openai.com/')
            $request.Timeout = 10000
            $request.Method = 'GET'
            $response = $request.GetResponse()
            $response.Close()
            return $true
        } catch [System.Net.WebException] {
            # An HTTP answer of any kind — even a 404 — proves we reached the internet.
            $reachable = $false
            try { if ($_.Exception.Response) { $reachable = $true } } catch { }
            if ($reachable) { return $true }
        } catch { }
        if ($attempt -eq 1) { Start-Sleep -Seconds 3 }
    }
    return $false
}

# FAILMODE 16: git init fails because git itself is missing. Non-fatal, warn once.
function Initialize-GitRepo {
    param([string]$Path)
    if (Test-Path -LiteralPath (Join-Path $Path '.git') -PathType Container) {
        Write-Log 'Version history is already set up in this folder — skipping.'
        return $true
    }
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
        Write-Log 'Version history is not available because git is not installed on this computer. Everything else works; your assistant can offer to set this up later.'
        return $false
    }
    if ($script:CheckMode) {
        Write-Log 'Version history is not set up yet; a real run would start it.'
        return $true
    }
    try {
        & git -C $Path init --quiet *> $null
    } catch { }
    if (Test-Path -LiteralPath (Join-Path $Path '.git') -PathType Container) {
        Write-Log 'Started version history in your folder, so nothing can be lost.'
        return $true
    }
    Write-Log 'Could not start version history here. Everything else still works.'
    return $false
}

# FAILMODE 17: the run was interrupted partway (Ctrl-C, closed window, power loss).
# Nothing extra to detect: every step above is safe to repeat, so re-running the
# whole checklist is the fix. This marker records that the run reached the end.
function Set-RunComplete {
    param([string]$Path)
    $marker = Join-Path (Join-Path $Path 'CONTROL') '.setup-complete'
    if ($script:CheckMode) {
        if (Test-Path -LiteralPath $marker -PathType Leaf) {
            Write-Log 'A previous setup run finished all the way through.'
        } else {
            Write-Log 'No completed setup run on record — the last one may have been interrupted. Re-running is safe.'
        }
        return
    }
    try {
        $controlDir = Join-Path $Path 'CONTROL'
        if (-not (Test-Path -LiteralPath $controlDir -PathType Container)) {
            New-Item -ItemType Directory -Path $controlDir -Force | Out-Null
        }
        [System.IO.File]::WriteAllText($marker, (Get-Stamp) + "`n")
    } catch { }
}

function Test-WasInterrupted {
    param([string]$Path)
    -not (Test-Path -LiteralPath (Join-Path (Join-Path $Path 'CONTROL') '.setup-complete') -PathType Leaf)
}

# FAILMODE 18: drift — a shipped file moved, renamed, or deleted after setup.
# Same inventory as failure mode 4, but runnable at any time, not just at setup.
function Test-ForDrift {
    param([string]$Source, [string]$Destination)
    $gone = 0
    foreach ($rel in Get-ShippedFiles $Source) {
        if (-not (Test-Path -LiteralPath (Join-Path $Destination $rel))) {
            $gone++
            Write-Log ("Missing from your folder: {0}" -f $rel)
        }
    }
    if ($gone -eq 0) {
        Write-Log 'Every file that should be in your folder is there.'
        return $true
    }
    Write-Log ("{0} file(s) are missing. Re-running setup puts them back, or ask your assistant to restore them from version history." -f $gone)
    return $false
}

# ------------------------------------------------------- Windows extras (T10) --
# Shortcuts, not symlinks: New-Item -ItemType SymbolicLink needs elevation or
# Developer Mode on Windows, a .lnk from WScript.Shell needs neither.

function New-AssistantShortcut {
    param([string]$Target, [string]$LinkPath, [string]$Description)
    if ($script:CheckMode -or $script:DryRun) { return $false }
    if (Test-Path -LiteralPath $LinkPath) { return $true }
    try {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($LinkPath)
        $shortcut.TargetPath = $Target
        $shortcut.Description = $Description
        $shortcut.Save()
        return (Test-Path -LiteralPath $LinkPath)
    } catch {
        return $false
    }
}
