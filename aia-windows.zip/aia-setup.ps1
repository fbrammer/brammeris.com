<#
.SYNOPSIS
  aia-setup.ps1 — the guided installer for your AI assistant (Windows).

.DESCRIPTION
  The Windows twin of aia-setup.sh. Same steps, same eighteen failure modes, same
  exit codes.

  Usage:
    .\aia-setup.ps1                    run the full setup
    .\aia-setup.ps1 -Check             doctor mode: check everything, change nothing
    .\aia-setup.ps1 -Base <path>       put the assistant folder somewhere else
    .\aia-setup.ps1 -EnvFile <path>    read a setup file from somewhere else

  Exit codes: 0 success, 1 a stop-the-run failure, 2 a bad command line.

  Running this on Windows:
    This script does NOT change your machine's PowerShell execution policy, and it
    never will — that is your computer's setting, not ours. Right-click the file
    and choose "Run with PowerShell". If Windows shows a blue "Windows protected
    your PC" box, that is SmartScreen noticing the file came from the internet;
    the setup page you downloaded this from explains what to click.

  Environment:
    AIA_DRY_RUN=1   rehearsal mode, used by the test suite and by anyone who wants
                    to see the steps without side effects on their system. It still
                    creates the assistant folder, unpacks files, starts version
                    history and merges settings — so the "check, then skip if
                    already correct" logic is genuinely exercised and a second run
                    reports everything as already done. It does NOT install Hermes,
                    open a browser, start the local key page, or make any network
                    call. Settings go to <BASE>\.hermes\ rather than your real
                    config folder.
    AIA_SOURCE      folder holding the shipped files (defaults to the zip or the
                    aiaFFS folder beside this script).
    AIA_CONFIG      full path to the real settings file.

  This script never prints, logs, or stores a credential. Keys you paste go
  straight from the local page into your settings folder and nowhere else.
#>

# Deliberately not [CmdletBinding()]: a plain param block still binds -Check,
# -Base and -EnvFile, but anything else lands in $args so we can answer a bad
# command line in plain words and exit 2, rather than with a binder stack trace.
param(
    [switch]$Check,
    [string]$Base = '',
    [string]$EnvFile = '.\env.txt',
    [switch]$Help
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

function Show-Usage {
    Write-Host 'Usage: aia-setup.ps1 [-Check] [-Base <path>] [-EnvFile <path>]'
}

if ($Help) { Show-Usage; exit 0 }

# Anything PowerShell could not bind to a declared parameter is a bad command line.
if ($args -and $args.Count -gt 0) {
    Write-Host ("I do not understand the option: " + $args[0])
    Show-Usage
    exit 2
}
if ($PSBoundParameters.ContainsKey('Base') -and -not $Base) { Show-Usage; exit 2 }
if ($PSBoundParameters.ContainsKey('EnvFile') -and -not $EnvFile) { Show-Usage; exit 2 }

$script:ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $script:ScriptDir 'lib\checks.ps1')

$script:CheckMode = [bool]$Check
$script:DryRun = ($env:AIA_DRY_RUN -eq '1')
$script:EnvFilePath = $EnvFile
$script:Base = $Base
$script:HermesBin = ''
$script:SourceDir = ''
$script:Completed = @()
$script:WorkingProviders = @()
$script:EnvBase = ''
$script:EnvProviders = ''
$script:EnvVersion = ''
$script:KeyPageResult = $null
$script:RerunCommand = 'powershell -File "' + $PSCommandPath + '"'

# ------------------------------------------------------- where things live --

function Resolve-SourceDir {
    if ($env:AIA_SOURCE -and (Test-Path -LiteralPath $env:AIA_SOURCE -PathType Container)) {
        $script:SourceDir = $env:AIA_SOURCE
        return $true
    }
    $zip = Join-Path $script:ScriptDir 'aiaFFS.zip'
    if (Test-Path -LiteralPath $zip -PathType Leaf) {
        try {
            $work = Join-Path ([System.IO.Path]::GetTempPath()) ('aiaFFS-' + [guid]::NewGuid().ToString('N'))
            New-Item -ItemType Directory -Path $work -Force | Out-Null
            Expand-Archive -LiteralPath $zip -DestinationPath $work -Force
            $script:SourceDir = $work
            return $true
        } catch { }
    }
    $beside = Join-Path (Split-Path -Parent $script:ScriptDir) 'aiaFFS'
    if (Test-Path -LiteralPath $beside -PathType Container) {
        $script:SourceDir = (Resolve-Path -LiteralPath $beside).ProviderPath
        return $true
    }
    return $false
}

# --------------------------------------------- the local key-entry page (10) --
# Binds the loopback interface on a free port, serves one small form, takes one
# POST, checks each key against its provider live, and shuts down. Accepted keys
# go straight into the settings folder from inside this function, so no key is
# ever printed, logged, or handed to another process.

$script:KeyPageForm = @'
<!doctype html><meta charset=utf-8><title>Your backup keys</title>
<style>body{font:16px system-ui;margin:3rem auto;max-width:34rem}
input{width:100%;padding:.5rem;font:inherit}label{display:block;margin:1.2rem 0 .3rem}
button{margin-top:1.5rem;padding:.6rem 1.2rem;font:inherit}.e{color:#a00}</style>
<h1>Your backup keys</h1>
<p>This page is running on your own computer. Nothing you type here leaves it &mdash;
it goes into your settings file and nowhere else. Leave a box empty to skip that
provider; you can add it later by asking your assistant.</p>
<p class=e>__MESSAGE__</p>
<form method=post>
<label>OpenRouter key (optional)</label><input name=openrouter type=password autocomplete=off>
<label>NVIDIA key (optional)</label><input name=nvidia type=password autocomplete=off>
<button type=submit>Save and finish</button></form>
'@

function Get-FreeLoopbackPort {
    $probe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0)
    $probe.Start()
    $port = $probe.LocalEndpoint.Port
    $probe.Stop()
    return $port
}

function Send-KeyPageResponse {
    param($Context, [string]$Body)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Body)
    $Context.Response.StatusCode = 200
    $Context.Response.ContentType = 'text/html; charset=utf-8'
    $Context.Response.ContentLength64 = $bytes.Length
    $Context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Context.Response.OutputStream.Close()
}

function Invoke-KeyPageOnce {
    if ($script:DryRun -or $script:CheckMode) { return $false }

    $providers = @{
        'openrouter' = 'OPENROUTER_API_KEY'
        'nvidia'     = 'NVIDIA_API_KEY'
    }
    $result = @{ submitted = $false; accepted = @(); rejected = @() }
    $listener = $null
    $url = $null
    try {
        $port = Get-FreeLoopbackPort
        # A non-elevated process may register the loopback name without a URL ACL;
        # a literal 127.0.0.1 prefix can need one. Prefer the name, keep the
        # numeric form as the documented fallback. Either way it is loopback only.
        #
        # A fresh HttpListener per attempt, never a reused one: an instance whose
        # Start() has already thrown is not reliably reusable, so clearing its
        # Prefixes and trying again could fail for reasons that have nothing to do
        # with the prefix. Building a new object keeps each attempt independent.
        foreach ($prefix in @("http://localhost:$port/", "http://127.0.0.1:$port/")) {
            $candidate = [System.Net.HttpListener]::new()
            try {
                $candidate.Prefixes.Add($prefix)
                $candidate.Start()
                $listener = $candidate
                $url = $prefix
                break
            } catch {
                try { $candidate.Close() } catch { }
            }
        }
        if (-not $url) { return $false }

        Write-Say ("Opening the key page on your own computer: " + $url)
        Write-Say 'If it did not open, open that address yourself in your browser.'
        # The page has to actually open — printing the address alone is not enough.
        Open-InBrowser $url | Out-Null

        $timeoutSeconds = 300
        if ($env:AIA_KEY_PAGE_TIMEOUT) { $timeoutSeconds = [int]$env:AIA_KEY_PAGE_TIMEOUT }
        $deadline = (Get-Date).AddSeconds($timeoutSeconds)

        while ((Get-Date) -lt $deadline) {
            $pending = $listener.GetContextAsync()
            $remaining = [int]([Math]::Max(1, ($deadline - (Get-Date)).TotalMilliseconds))
            if (-not $pending.Wait($remaining)) { break }
            $context = $pending.Result

            if ($context.Request.HttpMethod -ne 'POST') {
                Send-KeyPageResponse $context ($script:KeyPageForm -replace '__MESSAGE__', '')
                continue
            }

            $reader = [System.IO.StreamReader]::new($context.Request.InputStream, [System.Text.Encoding]::UTF8)
            $body = $reader.ReadToEnd()
            $reader.Close()
            $form = @{}
            foreach ($pair in $body.Split('&')) {
                if (-not $pair) { continue }
                $eq = $pair.IndexOf('=')
                if ($eq -lt 1) { continue }
                $form[[System.Uri]::UnescapeDataString($pair.Substring(0, $eq).Replace('+', ' '))] =
                    [System.Uri]::UnescapeDataString($pair.Substring($eq + 1).Replace('+', ' '))
            }

            $good = 0
            $bad = @()
            foreach ($provider in @('openrouter', 'nvidia')) {
                $secret = ''
                if ($form.ContainsKey($provider)) { $secret = ([string]$form[$provider]).Trim() }
                if (-not $secret) { continue }
                if (Test-ProviderKey $provider $secret) {
                    # Only a verified write counts as a working provider.
                    if (Save-Secret $providers[$provider] $secret $script:HermesEnvFile) {
                        $good++
                        $result.accepted += $provider
                    } else {
                        $bad += $provider
                    }
                } else {
                    $bad += $provider
                }
                $secret = $null
            }
            $body = $null
            $form = $null

            if ($bad.Count -gt 0 -and $good -eq 0) {
                # FAILMODE 12 retry: same page, plain words, no key echoed back.
                $result.rejected = $bad
                Send-KeyPageResponse $context ($script:KeyPageForm -replace '__MESSAGE__',
                    'That key did not work. Check it and try again, or leave it empty to skip.')
                continue
            }
            $result.submitted = $true
            $result.rejected = $bad
            Send-KeyPageResponse $context '<!doctype html><meta charset=utf-8><p>Saved. You can close this tab.'
            break
        }
        $script:KeyPageResult = $result
        return $true
    } catch {
        return $false
    } finally {
        if ($listener) {
            try { $listener.Stop() } catch { }
            try { $listener.Close() } catch { }
        }
    }
}

# ------------------------------------------- the two credential moments (7/8) --
# Both are safe to call twice: each checks first and skips what is already done.
# That is what lets failure mode 13 run them one more time before stopping.

function Invoke-OAuthStep {
    Write-Step 'Signing in to your main AI connection'
    Write-Say "In a moment a browser tab will open on OpenAI's own sign-in page."
    Write-Say 'You are signing in to OpenAI directly — the sign-in happens between your browser and them, and nothing you type there passes through this installer or any server of ours.'
    Write-Say 'When you have finished signing in, come back to this window and it will carry on by itself.'
    if ($script:DryRun) {
        Write-Log 'Rehearsal run: skipping the browser sign-in.'
        return
    }
    if (Test-OAuthPresent) {
        Write-Log 'You are already signed in — skipping.'
        $script:WorkingProviders += 'openai-codex'
        return
    }
    # FAILMODE 15: don't start a network step with no network.
    if (-not (Test-Network)) {
        Stop-Setup 'there is no internet connection right now. Nothing you have done so far is lost — run this again when you are back online.'
    }
    # FAILMODE 8: if the browser never opens, print the address to open by hand.
    Open-InBrowser 'https://auth.openai.com/device' | Out-Null
    if ($script:HermesBin) {
        try { & $script:HermesBin auth login openai *> $null } catch { }
    }
    # FAILMODE 9: tab closed or declined — offer one retry, then carry on.
    if (-not (Test-OAuthPresent) -and (Test-Interactive)) {
        Write-Say 'It looks like the sign-in was not completed. Would you like to try once more? [y/N]'
        $answer = Read-Host
        if ($answer -match '^[Yy]') {
            Open-InBrowser 'https://auth.openai.com/device' | Out-Null
            if ($script:HermesBin) {
                try { & $script:HermesBin auth login openai *> $null } catch { }
            }
        }
    }
    if (Test-OAuthPresent) {
        $script:WorkingProviders += 'openai-codex'
        Add-Completed 'your main AI connection'
    } else {
        Write-Log 'Carrying on without the main connection. Your assistant will use the free backup models instead. That is a normal way to finish, not a failure.'
    }
}

function Invoke-KeyPageStep {
    Write-Step 'Your free backup connections'
    Write-Say 'Next, a small page opens in your browser that is running on this computer and nowhere else.'
    Write-Say 'It asks for the free backup keys from OpenRouter and NVIDIA, and whatever you paste goes straight into your own settings file — it is never sent to us, never shown on screen, and never written into the log.'
    Write-Say 'If you would rather skip this, close the page and setup will finish without backups.'
    if ($script:DryRun) {
        Write-Log 'Rehearsal run: skipping the local key page.'
        return
    }
    if (-not (Test-Network)) {
        Write-Log 'No internet connection, so backup keys cannot be checked right now. Skipping this step; you can add them later by asking your assistant.'
        return
    }
    if (Start-KeyPage) {
        if ($script:KeyPageResult -and $script:KeyPageResult.submitted) {
            foreach ($provider in $script:KeyPageResult.accepted) {
                $script:WorkingProviders += $provider
                Write-Log ("Your {0} backup connection is set up and working." -f $provider)
            }
            if ($script:KeyPageResult.accepted.Count -eq 0) {
                # FAILMODE 11: nothing usable submitted is a fine outcome.
                Write-NoKeysSubmitted
            } else {
                Add-Completed 'your backup connections'
            }
        } else {
            # FAILMODE 11: nothing submitted is a fine outcome.
            Write-NoKeysSubmitted
        }
        return
    }
    # Last resort only: the local page could not start at all.
    if (-not (Test-Interactive)) {
        Write-NoKeysSubmitted
        return
    }
    Write-Say 'Paste your OpenRouter key here, or press Enter to skip (it will not be shown as you type):'
    $typed = Read-Host -AsSecureString
    $plain = $null
    try {
        $plain = [System.Net.NetworkCredential]::new('', $typed).Password
        if ($plain -and (Test-ProviderKey 'openrouter' $plain)) {
            if (Save-Secret 'OPENROUTER_API_KEY' $plain $script:HermesEnvFile) {
                $script:WorkingProviders += 'openrouter'
                Write-Log 'Your openrouter backup connection is set up and working.'
            } else {
                Write-Log ("That backup connection could not be saved to {0}. Setup will carry on without it." -f $script:HermesEnvFile)
            }
        }
    } finally {
        $plain = $null
        $typed = $null
    }
}

# ------------------------------------------------------------------- steps --

function Invoke-Main {
    Write-Say 'Setting up your assistant.'
    Write-Say 'Re-running this is always safe. Nothing is ever deleted.'

    # --- Step 1: the setup file from the web page (FAILMODE 3 handled inside).
    Write-Step 'Reading your setup file'
    Read-SetupEnvFile $script:EnvFilePath | Out-Null

    # --- Step 2: resolve and create the base folder.
    Write-Step "Your assistant's folder"
    $defaultBase = Join-Path $env:USERPROFILE 'AI'
    if (-not $script:Base -and $script:EnvBase) { $script:Base = $script:EnvBase }
    if (-not $script:Base) {
        # FAILMODE 3 (continued): with no setup file to tell us, ask. If nobody is
        # there to answer — a scheduled task, a pipe — fall through to the default.
        if ((Test-Interactive) -and -not $script:CheckMode) {
            Write-Say 'Where would you like your assistant to keep its folder?'
            Write-Say ("Press Enter to use {0}, or type another location." -f $defaultBase)
            $typedBase = Read-Host
            $script:Base = if ($typedBase) { $typedBase } else { $defaultBase }
        } else {
            $script:Base = $defaultBase
            Write-Say ("Using the usual location: " + $script:Base)
        }
    }
    $script:RerunCommand = 'powershell -File "' + $PSCommandPath + '" -Base "' + $script:Base + '"'
    # The settings path can depend on the base folder (rehearsal runs keep settings
    # inside it), so resolve it here — before any of the early -Check doctor exits
    # below, which would otherwise report against a stale path.
    Set-ConfigPaths

    if (Test-Path -LiteralPath $script:Base -PathType Container) {
        Write-Say ("Your folder is already there: " + $script:Base)
    } elseif ($script:CheckMode) {
        Write-Say ("Your folder does not exist yet: " + $script:Base)
        Write-Say 'Nothing was created — this is a check-only run.'
        Invoke-Doctor | Out-Null
        exit 0
    } else {
        try { New-Item -ItemType Directory -Path $script:Base -Force | Out-Null } catch { }
    }

    # FAILMODE 1: the folder has to be somewhere you can actually write. If the
    # chosen place will not take it, fall back to the usual location for this
    # computer and say where things went; stop only if that fails too.
    if (-not (Test-BaseWritable $script:Base)) {
        if ($script:CheckMode) {
            # Doctor mode changes nothing: say what a real run would do, then report.
            Write-Say ("The folder {0} cannot be written to." -f $script:Base)
            if ($script:Base -ne $defaultBase) {
                Write-Say ("A real run would fall back to the usual location for this computer: " + $defaultBase)
            }
            Write-Say 'Nothing was created — this is a check-only run.'
            Invoke-Doctor | Out-Null
            exit 1
        }
        if ($script:Base -ne $defaultBase) {
            Write-Say ("The folder {0} cannot be used — it may be read-only, or the disk may be full." -f $script:Base)
            Write-Say ("Falling back to the usual location for this computer: " + $defaultBase)
            $script:Base = $defaultBase
            $script:RerunCommand = 'powershell -File "' + $PSCommandPath + '" -Base "' + $script:Base + '"'
            try { New-Item -ItemType Directory -Path $script:Base -Force | Out-Null } catch { }
        }
        if (-not (Test-BaseWritable $script:Base)) {
            Stop-Setup ("the folder {0} cannot be written to. It may be read-only, or the disk may be full. Pick a different location with -Base and try again." -f $script:Base)
        }
    }
    Add-Completed ("your assistant's folder at " + $script:Base)
    # FAILMODE 2: warn, never block, on cloud-synced locations.
    Test-CloudSyncPath $script:Base | Out-Null
    # Re-resolve: the FAILMODE 1 fallback above may have moved the base folder.
    Set-ConfigPaths

    if ($script:CheckMode) {
        $rc = Invoke-Doctor
        exit $rc
    }

    # FAILMODE 17: if the last run was interrupted, everything below simply repeats.
    if (Test-WasInterrupted $script:Base) {
        Write-Log 'Picking up where the last run left off. Every step checks itself first.'
    } else {
        Write-Log 'This folder was already set up once; re-checking everything.'
    }

    # --- Step 3: version history (FAILMODE 16 handled inside).
    Write-Step 'Version history'
    if (Initialize-GitRepo $script:Base) { Add-Completed 'version history' }

    # --- Step 4: unpack the files (FAILMODE 4 and 5 handled inside).
    Write-Step "Your assistant's files"
    if (-not (Resolve-SourceDir)) {
        Stop-Setup 'the file bundle that should sit beside this script is missing. Download the zip again and unpack it before running this.'
    }
    Protect-EditedFiles $script:SourceDir $script:Base | Out-Null
    Restore-MissingFiles $script:SourceDir $script:Base | Out-Null
    Add-Completed "your assistant's files"

    # --- Step 5: install Hermes (FAILMODE 6 and 7 handled inside).
    Write-Step 'The program your assistant runs in'
    if ($script:DryRun) {
        Write-Log 'Rehearsal run: skipping the Hermes install and the desktop build.'
    } elseif (Install-HermesIfNeeded) {
        Add-Completed 'Hermes'
        # Native Windows Hermes home is %LOCALAPPDATA%\hermes — see the note
        # in Set-ConfigPaths.
        $builtMarker = Join-Path (Join-Path $env:LOCALAPPDATA 'hermes') 'desktop-built'
        if (Test-Path -LiteralPath $builtMarker -PathType Leaf) {
            Write-Log 'The desktop app is already built — skipping.'
        } else {
            $built = $false
            try {
                & $script:HermesBin desktop --build-only *> $null
                $built = ($LASTEXITCODE -eq 0)
            } catch { }
            if ($built) {
                $markerDir = Split-Path -Parent $builtMarker
                if (-not (Test-Path -LiteralPath $markerDir -PathType Container)) {
                    New-Item -ItemType Directory -Path $markerDir -Force | Out-Null
                }
                [System.IO.File]::WriteAllText($builtMarker, (Get-Stamp) + "`n")
                Write-Log 'Built the desktop app.'
            } else {
                Write-Log 'The desktop app did not build. The assistant still works from the terminal; you can ask it to try the desktop build again later.'
            }
        }
    } else {
        Stop-Setup 'Hermes could not be installed. Install it by hand: open PowerShell and run iex (irm https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.ps1) — then run this script again; it will pick up where it left off.'
    }

    # --- Step 6: settings (FAILMODE 14 handled inside).
    Write-Step 'Your settings'
    Merge-Config (Join-Path $script:SourceDir 'config-template.yaml') $script:ConfigFile | Out-Null
    Add-Completed 'your settings file'

    # --- Step 7: the first credential moment — sign in with your browser.
    Invoke-OAuthStep
    Invoke-KeyPageStep

    # --- Step 8: an easy way back in, without needing elevation for a symlink.
    Write-Step 'A shortcut to your assistant'
    $desktop = [Environment]::GetFolderPath('Desktop')
    $documents = [Environment]::GetFolderPath('MyDocuments')
    foreach ($place in @($desktop, $documents)) {
        if (-not $place) { continue }
        $link = Join-Path $place 'Your AI Assistant.lnk'
        if (New-AssistantShortcut $script:Base $link 'Your AI assistant folder') {
            Write-Log ("There is a shortcut to your assistant's folder at {0}." -f $link)
        }
    }

    # --- Step 9: the setup file has done its job.
    Write-Step 'Tidying up'
    if (Test-Path -LiteralPath $script:EnvFilePath -PathType Leaf) {
        try {
            Remove-Item -LiteralPath $script:EnvFilePath -Force
            Write-Log 'Removed the setup file you downloaded; it is not needed any more.'
        } catch { }
    } else {
        Write-Log 'The setup file is already gone — nothing to tidy.'
    }

    # --- Step 10: is anything actually working? (FAILMODE 13)
    Write-Step 'Checking that your assistant can actually talk to something'
    if ($script:DryRun) {
        Write-Log 'Rehearsal run: skipping the live connection check.'
    } elseif (-not (Test-AnyProviderWorks)) {
        # FAILMODE 13: nothing works yet — run both credential steps once more
        # before giving up, then stop honestly rather than hand over a dead assistant.
        Write-Say 'Nothing is answering yet, so let us try the sign-in and the key page one more time.'
        Invoke-OAuthStep
        Invoke-KeyPageStep
        if (-not (Test-AnyProviderWorks)) {
            Stop-Setup 'your assistant has no working AI connection, even after a second try, so handing it to you now would only waste your time. Run the command below to try again.'
        }
        Add-Completed 'a working AI connection'
    } else {
        Add-Completed 'a working AI connection'
    }

    # --- Step 11: the full self-check, then the handoff.
    Invoke-Doctor | Out-Null
    Set-RunComplete $script:Base
    Write-Handoff
    Write-Say ''
    Write-Say 'Setup finished.'
    return 0
}

# ---------------------------------------------------------------- the doctor --
# Runs every check. In -Check mode it writes nothing at all.

function Invoke-Doctor {
    $rc = 0
    Write-Step 'Full check'
    if (-not (Test-BaseWritable $script:Base)) {
        Write-Say ("Check 1: the folder {0} cannot be written to." -f $script:Base)
        $rc = 1
    }
    Test-CloudSyncPath $script:Base | Out-Null
    Read-SetupEnvFile $script:EnvFilePath | Out-Null
    if (Resolve-SourceDir) {
        if (-not (Test-ForDrift $script:SourceDir $script:Base)) { $rc = 1 }   # checks 3, 4 and 18
        Protect-EditedFiles $script:SourceDir $script:Base | Out-Null          # check 5
    }
    if ((Get-Command hermes -ErrorAction SilentlyContinue) -or (Find-HermesOnDisk)) {
        Write-Say 'Hermes is installed.'
    } else {
        Write-Say 'Hermes is not installed yet.'
        $rc = 1
    }
    if (-not $script:DryRun -and $script:CheckMode) {
        if (-not (Test-Network)) {
            Write-Say 'There is no internet connection right now.'
            $rc = 1
        }
    }
    Initialize-GitRepo $script:Base | Out-Null
    if ($script:SourceDir) {
        Merge-Config (Join-Path $script:SourceDir 'config-template.yaml') $script:ConfigFile | Out-Null
    }
    Set-RunComplete $script:Base
    return $rc
}

# ------------------------------------------------------------- the handoff --

function Write-Handoff {
    $out = Join-Path $script:Base 'MEET-YOUR-ASSISTANT.txt'
    $promptSrc = Join-Path $script:ScriptDir 'lib\meet-prompt.txt'
    if (-not (Test-Path -LiteralPath $promptSrc -PathType Leaf)) { return }
    $prompt = ([System.IO.File]::ReadAllText($promptSrc)).Replace('<BASE>', $script:Base)
    try { [System.IO.File]::WriteAllText($out, $prompt) } catch { }
    Write-Say ''
    Write-Say '------------------------------------------------------------------'
    Write-Say 'Copy everything between the lines and paste it into your assistant'
    Write-Say '------------------------------------------------------------------'
    Write-Say $prompt
    Write-Say '------------------------------------------------------------------'
    Write-Say ("If the copy goes wrong, the same message is saved at " + $out)
}

# ------------------------------------------------------------------- start --

function Set-ConfigPaths {
    if ($env:AIA_CONFIG) {
        $script:ConfigFile = $env:AIA_CONFIG
    } elseif ($script:DryRun) {
        $root = if ($script:Base) { $script:Base } else { Join-Path $env:USERPROFILE 'AI' }
        $script:ConfigFile = Join-Path (Join-Path $root '.hermes') 'config.yaml'
    } else {
        # Native Windows Hermes sets HERMES_HOME=%LOCALAPPDATA%\hermes (no
        # leading dot, and under LOCALAPPDATA, not USERPROFILE) — confirmed
        # against the real installer's own docs. This is NOT the same shape
        # as the %USERPROFILE%\.hermes convention Mac/Linux use.
        $script:ConfigFile = Join-Path (Join-Path $env:LOCALAPPDATA 'hermes') 'config.yaml'
    }
    # Hermes reads fallback-provider credentials from a .env file beside its
    # config.yaml, in NAME=value form, which config.yaml points at through
    # `api_key_env`. On native Windows that is %LOCALAPPDATA%\hermes\.env.
    $script:HermesEnvFile = Join-Path (Split-Path -Parent $script:ConfigFile) '.env'
}

Set-ConfigPaths
exit (Invoke-Main)
